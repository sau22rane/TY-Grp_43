#include "include/screen.h"
kmain()
{       
        clearScreen();
        print("Hi, And welcome to the IknowOS\nPlease don't forget to subscribe to https://www.youtube.com/user/iknowbrain\nThank you");
}
